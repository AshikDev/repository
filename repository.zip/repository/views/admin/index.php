<div class="container-fluid">
    <div class="panel panel-default">
        <div class="panel-heading"><strong>Repository</strong> <?= Yii::t('RepositoryModule.base', 'configuration') ?></div>

        <div class="panel-body">
            <p><?= Yii::t('RepositoryModule.base', 'Welcome to the admin only area.') ?></p>
        </div>
    </div>
</div>