<?php
/* @var $this \yii\web\View */
/* @var $keyword string */
/* @var $group humhub\modules\user\models\Group */
/* @var $users humhub\modules\user\models\User[] */

/* @var $pagination yii\data\Pagination */

use humhub\libs\Html;
use humhub\widgets\ModalButton;

$addFolderUrl = Yii::$app->urlManager->createUrl('/repository/project/create');

?>

<div class="clearfix files-action-menu">

    <div style="display:block;" class="pull-right">
        <!-- Directory dropdown -->
        <?php if (Yii::$app->user->isAdmin()): ?>
        <div class="btn-group">
            <?= ModalButton::defaultType(Yii::t('CfilesModule.base', 'Add project'))->load($addFolderUrl)->icon('fa-plus-circle')->cssClass('dropdown-toggle')?>
        </div>
        <?php endif; ?>

    </div>
</div>

<div class="panel panel-default">

    <div class="panel-heading">
        Project Overview
    </div>

    <div class="panel-body">
        <?= Html::beginForm('', 'get', ['class' => 'form-search']); ?>
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="form-group form-group-search">
                    <?= Html::hiddenInput('page', '1'); ?>
                    <?= Html::textInput("keyword", $keyword, ['class' => 'form-control form-search', 'placeholder' => Yii::t('DirectoryModule.base', 'search for projects')]); ?>
                    <?= Html::submitButton(Yii::t('DirectoryModule.base', 'Search'), ['class' => 'btn btn-default btn-sm form-button-search']); ?>
                </div>
            </div>
            <div class="col-md-3"></div>
        </div>
        <?= Html::endForm(); ?>

        <?php if (count($projects) == 0): ?>
            <p><?= Yii::t('DirectoryModule.base', 'No projects found!'); ?></p>
        <?php endif; ?>
    </div>

    <hr>

    <ul class="media-list">
        <?php foreach ($projects as $project) : ?>
            <li>
                <div class="media">
                    <span class="pull-left">
                        <a href="">
                            <img class="img-rounded" src="https://picsum.photos/100/100" style="width: 50px; height: 50px">
                        </a>
                    </span>
                    <div class="media-body">
                        <div style="font-weight: bold;">
                            <?= Html::a($project->name, ['/ccfiles/browse', 'cguid' => $project->guid]); ?>
                        </div>
                        <p><?= Html::encode($project->description); ?></p>
                    </div>
                </div>
            </li>
        <?php endforeach; ?>
    </ul>

</div>

<div class="pagination-container">
    <?= \humhub\widgets\LinkPager::widget(['pagination' => $pagination]); ?>
</div>
