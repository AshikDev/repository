<?php

namespace data\repository\humhub\modules\repository\controllers;

use humhub\components\Controller;
use Yii;
use humhub\modules\repository\models\Project;
use yii\data\Pagination;

class IndexController extends Controller
{

    public $subLayout = "@repository/views/layouts/default";

    /**
     * Renders the index view for the module
     *
     * @return string
     */
    public function actionIndex()
    {
        $keyword = Yii::$app->request->get('keyword', '');
        $page = (int) Yii::$app->request->get('page', 1);

        $searchOptions = [
            'model' => Project::class,
            'page' => $page,
            'pageSize' => 20,
        ];

        $searchResultSet = Yii::$app->search->find($keyword, $searchOptions);

        $pagination = new Pagination([
            'totalCount' => $searchResultSet->total,
            'pageSize' => $searchResultSet->pageSize
        ]);

        return $this->render('index', [
            'keyword' => $keyword,
            'projects' => Project::find()->all(),
            'pagination' => $pagination
        ]);
    }

}

