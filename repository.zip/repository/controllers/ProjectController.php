<?php

namespace data\repository\humhub\modules\repository\controllers;

use humhub\modules\admin\components\Controller;
use humhub\modules\repository\models\Project;

class ProjectController extends Controller
{

    /**
     * Render admin only page
     *
     * @return string
     */
    public function actionCreate()
    {
        $model = new Project();

        return $this->render('create', [
            'model' => $model
        ]);
    }

}

