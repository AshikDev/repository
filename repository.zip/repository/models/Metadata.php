<?php

namespace app\humhub\modules\repository\models;

use Yii;

/**
 * This is the model class for table "metadata".
 *
 * @property int $id
 * @property string $object
 * @property int $reading_time
 * @property string $summary
 * @property string $language
 * @property string $phase
 * @property string $finding
 * @property string $linkage
 * @property string $extra
 */
class Metadata extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'metadata';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['object', 'reading_time', 'summary'], 'required'],
            [['reading_time'], 'integer'],
            [['summary', 'finding'], 'string'],
            [['object', 'language'], 'string', 'max' => 50],
            [['phase'], 'string', 'max' => 250],
            [['linkage', 'extra'], 'string', 'max' => 550],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'object' => Yii::t('app', 'Object'),
            'reading_time' => Yii::t('app', 'Reading Time'),
            'summary' => Yii::t('app', 'Summary'),
            'language' => Yii::t('app', 'Language'),
            'phase' => Yii::t('app', 'Research Phase'),
            'finding' => Yii::t('app', 'Research Finding'),
            'linkage' => Yii::t('app', 'Linkage'),
            'extra' => Yii::t('app', 'Extra'),
        ];
    }

    /**
     * {@inheritdoc}
     * @return MetadataQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new MetadataQuery(get_called_class());
    }
}
