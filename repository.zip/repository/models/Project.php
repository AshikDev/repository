<?php

namespace humhub\modules\repository\models;

use humhub\modules\content\components\ContentContainerActiveRecord;
use humhub\modules\search\events\SearchAddEvent;
use humhub\modules\search\interfaces\Searchable;
use Yii;

/**
 * This is the model class for table "project".
 *
 * @property int $id
 * @property string $name
 * @property string $description
 * @property string $overview
 * @property string $date_from
 * @property string $date_to
 * @property string $logo
 * @property string $extra
 */
class Project extends ContentContainerActiveRecord implements Searchable
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'project';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name', 'description', 'date_from', 'date_to', 'logo'], 'required'],
            [['description', 'overview'], 'string'],
            [['date_from', 'date_to', 'contentcontainer_id'], 'safe'],
            [['name'], 'string', 'max' => 150],
            [['guid'], 'string', 'max' => 45],
            [['logo', 'extra'], 'string', 'max' => 80],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'name' => Yii::t('app', 'Name'),
            'description' => Yii::t('app', 'Description'),
            'overview' => Yii::t('app', 'Overview'),
            'date_from' => Yii::t('app', 'Date From'),
            'date_to' => Yii::t('app', 'Date To'),
            'logo' => Yii::t('app', 'Logo'),
            'extra' => Yii::t('app', 'Extra'),
            'guid' => Yii::t('app', 'GUID'),
        ];
    }

    /**
     * {@inheritdoc}
     * @return ProjectQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new ProjectQuery(get_called_class());
    }

    public function getSearchAttributes()
    {
        $attributes = [
            'name' => $this->name,
            'description' => $this->description,
            'overview' => $this->overview
        ];

        $this->trigger(self::EVENT_SEARCH_ADD, new SearchAddEvent($attributes));

        return $attributes;
    }
}
