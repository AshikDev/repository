<?php

namespace app\humhub\modules\repository\models;

/**
 * This is the ActiveQuery class for [[Metadata]].
 *
 * @see Metadata
 */
class MetadataQuery extends \yii\db\ActiveQuery
{
    /*public function active()
    {
        return $this->andWhere('[[status]]=1');
    }*/

    /**
     * {@inheritdoc}
     * @return Metadata[]|array
     */
    public function all($db = null)
    {
        return parent::all($db);
    }

    /**
     * {@inheritdoc}
     * @return Metadata|array|null
     */
    public function one($db = null)
    {
        return parent::one($db);
    }
}
