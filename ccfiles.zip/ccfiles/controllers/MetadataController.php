<?php

/**
 * @link https://www.humhub.org/
 * @copyright Copyright (c) 2017 HumHub GmbH & Co. KG
 * @license https://www.humhub.com/licences
 */

namespace humhub\modules\ccfiles\controllers;

use Yii;
use yii\web\HttpException;
use humhub\modules\ccfiles\models\FileSystemItem;
use humhub\modules\ccfiles\models\forms\SelectionForm;
use humhub\modules\content\models\Content;
use humhub\modules\ccfiles\models\File;
use app\humhub\modules\repository\models\Metadata;

/**
 * Description of BrowseController
 *
 * @author luke, Sebastian Stumpf
 */
class MetadataController extends BrowseController
{
    public function actionFolder($id = null)
    {
        $metadata = Metadata::find()->where(['object' => $id])->one();
        if(empty($metadata) || $metadata == null) {
            $metadata = new  Metadata();
        }

        if ($metadata->load(Yii::$app->request->post())) {
            $metadata->object = $id;
            if ($metadata->save()) {
                $this->view->saved();
                return $this->htmlRedirect(null);
            }
        }

        return $this->renderPartial('modal_edit_folder', [
            'metadata' => $metadata,
            'submitUrl' => $this->getCurrentFolder()->createUrl('/ccfiles/metadata/folder', ['id' => $id])
        ]);
    }

    /**
     * Action to edit a given file.
     *
     * @return string
     */
    public function actionFile($id, $fromWall = 0)
    {
        $metadata = Metadata::find()->where(['object' => $id])->one();
        if(empty($metadata) || $metadata == null) {
            $metadata = new  Metadata();
        }

        if ($metadata->load(Yii::$app->request->post())) {
            $metadata->object = $id;
            if ($metadata->save()) {
                $this->view->saved();
                return $this->htmlRedirect(null);
            }
        }

        return $this->renderPartial('modal_edit_folder', [
            'metadata' => $metadata,
            'submitUrl' => $this->getCurrentFolder()->createUrl('/ccfiles/metadata/file', ['id' => $id])
        ]);
    }

    public function actionShow($id = null)
    {
        $folder = FileSystemItem::getItemById($id);

        if ($folder == null) {
            throw new HttpException(403);
        }

        $metadata = Metadata::find()->where(['object' => $id])->one();
        if(empty($metadata) || $metadata == null) {
            $metadata = new  Metadata();
        }

        return $this->renderPartial('modal_show_metadata', [
            'metadata' => $metadata,
            'folder' => $folder
        ]);
    }

    /**
     * @return string
     */
    public function actionMakePrivate()
    {
        return $this->updateVisibility(new SelectionForm(), Content::VISIBILITY_PRIVATE);
    }

    /**
     * @return string
     */
    public function actionMakePublic()
    {
        return $this->updateVisibility(new SelectionForm(), Content::VISIBILITY_PUBLIC);
    }

    /**
     * @param SelectionForm $model
     * @param $visibility
     * @return string
     */
    private function updateVisibility(SelectionForm $model, $visibility)
    {
        foreach ($model->selection as $itemId) {
            $item = FileSystemItem::getItemById($itemId);

            if(!$item->content->canEdit()) {
                throw new HttpException(403);
            }

            if ($item && $item->content->container->id === $this->contentContainer->id) {
                $item->updateVisibility($visibility);
                $item->content->save();
            }
        }

        return $this->renderFileList();
    }

}
