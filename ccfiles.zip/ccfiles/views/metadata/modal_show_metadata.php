<?php

use humhub\widgets\ModalButton;
use humhub\widgets\ModalDialog;
use yii\bootstrap\ActiveForm;

/* @var $folder \humhub\modules\cfiles\models\Folder */
/* @var $submitUrl string */

$header = Yii::t('CfilesModule.base', '<strong>Metadata</strong>');

?>

<?php ModalDialog::begin([
    'header' =>  $header,
    'animation' => 'fadeIn',
    'size' => 'small']) ?>

<?php $form = ActiveForm::begin(); ?>
    <div class="modal-body">
        <table class="table table-striped table-hover">
            <tr>
                <th>Name</th>
                <td><?= $folder->title; ?></td>
            </tr>
            <tr>
                <th>Format</th>
                <td><?= $folder->getItemType(); ?></td>
            </tr>
            <tr>
                <th>Size</th>
                <td><?= Yii::$app->formatter->asShortSize($folder->getSize(), 1); ?></td>
            </tr>
            <tr>
                <th>Anticipated reading time (Min)</th>
                <td><?= $metadata->reading_time; ?></td>
            </tr>
            <tr>
                <th>Created By</th>
                <td><?= $folder->getCreator()->displayName; ?></td>
            </tr>
            <tr>
                <th>Updated By</th>
                <td><?= $folder->getEditor()->displayName; ?></td>
            </tr>
            <tr>
                <th>Access permission</th>
                <td><?= $folder->getVisibilityTitle(); ?></td>
            </tr>
            <tr>
                <th>Summary</th>
                <td><?= $metadata->summary; ?></td>
            </tr>
            <tr>
                <th>Language</th>
                <td><?= $metadata->language; ?></td>
            </tr>
            <tr>
                <th>Research phase</th>
                <td><?= $metadata->phase; ?></td>
            </tr>
            <tr>
                <th>Research Findings</th>
                <td><?= $metadata->finding; ?></td>
            </tr>
            <tr>
                <th>Linkage to other files</th>
                <td><?= $metadata->linkage; ?></td>
            </tr>
        </table>
    </div>

    <div class="modal-footer">
        <?= ModalButton::cancel() ?>
    </div>
<?php ActiveForm::end() ?>

<?php ModalDialog::end() ?>