<?php

use humhub\widgets\ModalButton;
use humhub\widgets\ModalDialog;
use yii\bootstrap\ActiveForm;

/* @var $folder \humhub\modules\cfiles\models\Folder */
/* @var $submitUrl string */

$header = ($metadata->isNewRecord)
    ? Yii::t('CfilesModule.base', '<strong>Create</strong> Metadata')
    : Yii::t('CfilesModule.base', '<strong>Edit</strong> Metadata');

?>

<?php ModalDialog::begin([
    'header' =>  $header,
    'animation' => 'fadeIn',
    'size' => 'small']) ?>

<?php $form = ActiveForm::begin(); ?>
    <div class="modal-body">
        <?= $form->field($metadata, 'reading_time'); ?>
        <?= $form->field($metadata, 'summary')->textarea(); ?>
        <?= $form->field($metadata, 'language'); ?>
        <?= $form->field($metadata, 'phase'); ?>
        <?= $form->field($metadata, 'finding')->textarea(); ?>
        <?= $form->field($metadata, 'linkage'); ?>
    </div>

    <div class="modal-footer">
        <?= ModalButton::submitModal($submitUrl)?>
        <?= ModalButton::cancel() ?>
    </div>
<?php ActiveForm::end() ?>

<?php ModalDialog::end() ?>