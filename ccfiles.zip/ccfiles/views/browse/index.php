<?php

use yii\helpers\Html;
use humhub\modules\ccfiles\widgets\FolderView;
use humhub\modules\ccfiles\widgets\FileListContextMenu;

/* @var $folder humhub\modules\cfiles\models\Folder */
/* @var $contentContainer humhub\components\View */
/* @var $canWrite boolean */

$bundle = \humhub\modules\ccfiles\assets\Assets::register($this);

$this->registerJsConfig('cfiles', [
    'text' => [
        'confirm.delete' => Yii::t('CfilesModule.base', 'Do you really want to delete this {number} item(s) with all subcontent?'),
        'confirm.delete.header' => Yii::t('CfilesModule.base', '<strong>Confirm</strong> delete file'),
        'confirm.delete.confirmText' => Yii::t('CfilesModule.base', 'Delete')
    ],
    'showUrlModal' => [
        'head' => Yii::t('CfilesModule.base', '<strong>File</strong> url'),
        'headFile' => Yii::t('CfilesModule.base', '<strong>File</strong> download url'),
        'headFolder' => Yii::t('CfilesModule.base', '<strong>Folder</strong> url'),
        'info' => Yii::t('base', 'Copy to clipboard'),
        'buttonClose' => Yii::t('base', 'Close'),
    ]
]);
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Cyberrüsten
                </div>

                <div class="panel-body">

                    <?= Html::beginForm(null, null, ['data-target' => '#globalModal', 'id' => 'cfiles-form']); ?>
                    <div id="cfiles-container" class="panel panel-default cfiles-content">

                        <?=  FolderView::widget([
                            'contentContainer' => $contentContainer,
                            'folder' => $folder
                        ])?>

                    </div>
                    <?= Html::endForm(); ?>

                    <?= FileListContextMenu::widget(['folder' => $folder]); ?>

                </div>
            </div>
        </div>
    </div>
</div>


