<?php

use humhub\commands\IntegrityController;
use humhub\modules\space\widgets\Menu;
use humhub\modules\user\widgets\ProfileMenu;
use humhub\widgets\TopMenu;

return [
    'id' => 'ccfiles',
    'class' => 'humhub\modules\ccfiles\Module',
    'namespace' => 'humhub\modules\ccfiles',
    'events' => [
        [Menu::class, Menu::EVENT_INIT, ['humhub\modules\ccfiles\Events', 'onSpaceMenuInit']],
        [ProfileMenu::class, ProfileMenu::EVENT_INIT, ['humhub\modules\ccfiles\Events', 'onProfileMenuInit']],
        [IntegrityController::class, IntegrityController::EVENT_ON_RUN, ['humhub\modules\ccfiles\Events', 'onIntegrityCheck']]
    ]
];
?>