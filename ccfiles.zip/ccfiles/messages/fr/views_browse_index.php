<?php
return array (
  'Could not save file %title%. ' => 'Impossible d\'enregistrer le fichier %title%. ',
);
