<?php
return array (
  'Description' => 'Beschreibung',
  'Parent Folder ID' => 'ID des übergeordneten Ordners',
  'Title' => 'Titel',
);
