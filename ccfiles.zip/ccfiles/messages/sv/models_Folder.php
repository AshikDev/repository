<?php
return array (
  'Description' => 'Beskrivning',
  'Parent Folder ID' => 'Överordnad mapp ID',
  'Title' => 'Rubrik',
);
