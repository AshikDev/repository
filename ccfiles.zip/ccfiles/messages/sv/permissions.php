<?php
return array (
  'Add files' => 'Lägg till fil(er)',
  'Allows the user to modify or delete any files.' => 'Tillåter användaren att ändra eller radera filer.',
  'Allows the user to upload new files and create folders' => 'Tillåter användaren att ladda upp nya filer och skapa mappar',
  'Manage files' => 'Hantera filer',
);
