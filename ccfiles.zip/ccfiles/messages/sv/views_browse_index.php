<?php
return array (
  'Could not save file %title%. ' => 'Kunde inte skapa filen %title%.',
);
