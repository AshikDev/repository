<?php
return array (
  'Add files' => 'Legg til filer',
  'Allows the user to modify or delete any files.' => 'Gir brukeren rettigheter til å endre og slette alle filer.',
  'Allows the user to upload new files and create folders' => 'Gir brukeren rettigheter til å laste opp nye filer og opprette nye mapper.',
  'Manage files' => 'Administrer filer',
);
