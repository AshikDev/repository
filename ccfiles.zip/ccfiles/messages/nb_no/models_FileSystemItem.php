<?php
return array (
  'Is Public' => 'Er offentlig',
  'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => 'Merk: endringer i mappens synlighet, vil overføres til alle filer og mapper inneholdt i mappen.',
);
