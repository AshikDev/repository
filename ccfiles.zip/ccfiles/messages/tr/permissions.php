<?php
return array (
  'Add files' => 'Dosya ekle',
  'Allows the user to modify or delete any files.' => '',
  'Allows the user to upload new files and create folders' => '',
  'Manage files' => 'Dosyaları yönet',
);
