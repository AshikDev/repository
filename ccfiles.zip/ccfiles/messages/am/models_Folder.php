<?php

return [
    'Description' => '',
    'Parent Folder ID' => '',
    'Title' => '',
];
