<?php
return array (
  'Description' => 'Leírás',
  'Parent Folder ID' => '',
  'Title' => 'Név',
);
