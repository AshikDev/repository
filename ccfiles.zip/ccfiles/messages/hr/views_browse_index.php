<?php
return array (
  'Could not save file %title%. ' => 'Nije moguće spremiti datoteku %title%. ',
);
