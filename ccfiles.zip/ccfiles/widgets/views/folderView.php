<?php

use humhub\modules\ccfiles\widgets\BreadcrumbBar;
use humhub\modules\ccfiles\widgets\FileListMenu;
use humhub\modules\ccfiles\widgets\FileList;
use humhub\modules\ccfiles\widgets\FileSelectionMenu;
use humhub\modules\file\widgets\UploadProgress;
use yii\helpers\Html;

/* @var $this humhub\components\View */
/* @var $contentContainer humhub\components\View */
/* @var $folder humhub\modules\cfiles\models\Folder */
?>

<?= Html::beginTag('div', $options) ?>

<?= BreadcrumbBar::widget(['folder' => $folder, 'contentContainer' => $contentContainer]) ?>

<?= UploadProgress::widget(['id' => 'cfiles_progress']) ?>

<?= FileListMenu::widget([
    'folder' => $folder,
    'contentContainer' => $contentContainer,
]) ?>

<div id="fileList">
    <?= FileList::widget([
        'folder' => $folder,
        'contentContainer' => $contentContainer,
    ])?>
</div>
<?= Html::endTag('div') ?>

<?php

$baseUrl = Yii::$app->request->baseUrl;
//$fullPath = $baseUrl . '/ccfiles/metadata/show?id=folder_47';
//$fullPath = Yii::$app->urlManager->createUrl('/ccfiles/metadata/show', ['id' => 'folder_47']);
//$fullPath = $row->getShowMetadataUrl();

$this->registerJs("$('.metadataColumn').click(function(e) {

    e.preventDefault();
    var anchorUrl = $(this).attr('href');
    var modal = humhub.modules.ui.modal;
    modal.global.load(anchorUrl);
    
});", \yii\web\View::POS_READY);
