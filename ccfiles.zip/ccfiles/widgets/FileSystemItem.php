<?php

/**
 * @link https://www.humhub.org/
 * @copyright Copyright (c) 2015 HumHub GmbH & Co. KG
 * @license https://www.humhub.com/licences
 */

namespace humhub\modules\ccfiles\widgets;

use humhub\modules\ccfiles\models\File;
use humhub\modules\ccfiles\models\Folder;
use humhub\modules\ccfiles\models\rows\AbstractFileSystemItemRow;
use humhub\widgets\JsWidget;
use Yii;
use yii\helpers\Url;

/**
 * @inheritdoc
 */
class FileSystemItem extends JsWidget
{

    /**
     * @inheritdoc
     */
    public $jsWidget = 'cfiles.FileItem';

    /**
     * @var AbstractFileSystemItemRow
     */
    public $row;

    /**
     * @var boolean
     */
    public $itemsSelectable = true;

    /**
     * @inheritdoc
     */
    public function run()
    {
        $this->row->showSelect = $this->itemsSelectable;

        return $this->render('fileSystemItem', [
            'row' => $this->row,
            'options' => $this->getOptions()
        ]);
    }

//    public function getMetadataUrl()
//    {
//        return Url::to([
//            '/ccfiles/metadata'
//        ]);
//    }

    public function getData() {
        return [
            'cfiles-item' => $this->row->getItemId(),
            'cfiles-type' => $this->row->getType(),
            'cfiles-url' => $this->row->getUrl(),
            'cfiles-editable' => $this->row->canEdit(),
            'cfiles-url-full' => $this->row->getDisplayUrl(),
            'cfiles-wall-url' => $this->row->getWallUrl(),
            'cfiles-edit-url' => ($this->row->canEdit()) ? $this->row->getEditUrl() : '',
            'cfiles-metadata-url' => $this->row->getMetadataUrl(),
            'cfiles-show-metadata-url' => $this->row->getShowMetadataUrl(),
            'cfiles-move-url' => ($this->row->canEdit()) ? $this->row->getMoveUrl() : '',
        ];
    }

}
