<?php

/**
 * @link https://www.humhub.org/
 * @copyright Copyright (c) 2017 HumHub GmbH & Co. KG
 * @license https://www.humhub.com/licences
 */

namespace humhub\modules\ccfiles\widgets;

use humhub\modules\ccfiles\models\Folder;

/**
 * Wall Entry for Folder
 * 
 * Used for Search
 */
class WallEntryFolder extends \humhub\modules\content\widgets\WallEntry
{

    /**
     * @inheritdoc
     */
    public $editRoute = "/ccfiles/edit/folder";
    public $metadataRoute = "/ccfiles/metadata/folder";
    public $showMetadataRoute = "/ccfiles/metadata/show";

    /**
     * @inheritdoc
     */
    public $editMode = self::EDIT_MODE_MODAL;

    /**
     * @inheritdoc
     */
    public function run()
    {

        return $this->render('wallEntryFolder', [
                    'folder' => $this->contentObject,
                    'folderUrl' => $this->contentObject->getUrl()
        ]);
    }

    /**
     * Returns the edit url to edit the content (if supported)
     *
     * @return string url
     */
    public function getEditUrl()
    {
        if (empty(parent::getEditUrl())) {
            return "";
        }

        if ($this->contentObject instanceof Folder) {
            return $this->contentObject->content->container->createUrl($this->editRoute, ['id' => $this->contentObject->getItemId(), 'fromWall' => true]);
        }

        return "";
    }

    public function getMetadataUrl()
    {
        if (empty(parent::getMetadataUrl())) {
            return "";
        }

        if ($this->contentObject instanceof Folder) {
            return $this->contentObject->content->container->createUrl($this->metadataRoute, ['id' => $this->contentObject->getItemId(), 'fromWall' => true]);
        }

        return "";
    }

    public function getShowMetadataUrl()
    {
        if (empty(parent::getShowMetadataUrl())) {
            return "";
        }

        if ($this->contentObject instanceof Folder) {
            return $this->contentObject->content->container->createUrl($this->showMetadataRoute, ['id' => $this->contentObject->getItemId(), 'fromWall' => true]);
        }

        return "";
    }

}
