<?php

namespace humhub\modules\ccfiles\widgets;

use humhub\modules\ccfiles\models\Folder;
use humhub\modules\content\components\ContentContainerActiveRecord;
use humhub\widgets\JsWidget;

/**
 * Widget for rendering the file list bar.
 */
class FolderView extends JsWidget
{

    /**
     * @inheritdoc
     */
    public $jsWidget = 'cfiles.FolderView';

    /**
     * @inheritdoc
     */
    public $id = 'cfiles-folderView';

    /**
     * @var ContentContainerActiveRecord
     */
    public $contentContainer;

    /**
     * @var Folder
     */
    public $folder;

    /**
     * @inheritdoc
     */
    public $init = true;

    /**
     * @inheritdoc
     */
    public function getData()
    {
        return [
            'fid' => $this->folder->id,
            'upload-url' => $this->folder->createUrl('/ccfiles/upload'),
            'reload-file-list-url' => $this->folder->createUrl('/ccfiles/browse/file-list'),
            'delete-url' => $this->folder->createUrl('/ccfiles/delete'),
            'zip-upload-url' => $this->folder->createUrl('/ccfiles/zip/upload'),
            'download-archive-url' => $this->folder->createUrl('/ccfiles/zip/download'),
            'move-url' => $this->folder->createUrl('/ccfiles/move'),
            'import-url' => $this->folder->createUrl('/ccfiles/upload/import'),
        ];
    }

    /**
     * @inheritdoc
     */
    public function run() {        
        return $this->render('folderView', [
            'folder' => $this->folder,
            'options' => $this->getOptions(),
            'contentContainer' => $this->contentContainer
        ]);
    }

}