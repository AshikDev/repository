<?php

namespace humhub\modules\ccfiles\widgets;

use humhub\modules\ccfiles\permissions\ManageFiles;
use Yii;

/**
 * Widget for rendering the file list context menu.
 */
class FileListContextMenu extends \yii\base\Widget
{
    /**
     * Current folder model instance.
     * @var \humhub\modules\ccfiles\models\Folder
     */
    public $folder;
    

    /**
     * @inheritdoc
     */
    public function run()
    {
        $canWrite = $this->folder->content->container->can(ManageFiles::class);

        return $this->render('fileListContextMenu', [
            'folder' => $this->folder,
            'canWrite' => $canWrite,
            'zipEnabled' => !Yii::$app->getModule('ccfiles')->settings->get('disableZipSupport'),
        ]);
    }

}