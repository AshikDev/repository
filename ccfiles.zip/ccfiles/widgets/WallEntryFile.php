<?php

/**
 * @link https://www.humhub.org/
 * @copyright Copyright (c) 2015 HumHub GmbH & Co. KG
 * @license https://www.humhub.com/licences
 */

namespace humhub\modules\ccfiles\widgets;

use humhub\modules\file\converter\PreviewImage;
use humhub\modules\ccfiles\models\File;
use humhub\libs\MimeHelper;

/**
 * @inheritdoc
 */
class WallEntryFile extends \humhub\modules\content\widgets\WallEntry
{

    /**
     * @inheritdoc
     */
    public $editRoute = "/ccfiles/edit/file";

    public $metadataRoute = "/ccfiles/metadata/file";

    public $showMetadataRoute = "/ccfiles/metadata/show";

    /**
     * @inheritdoc
     */
    public $editMode = self::EDIT_MODE_MODAL;

    /**
     * @inheritdoc
     */
    public function run()
    {
        $cFile = $this->contentObject;

        $folderUrl = '#';
        if ($cFile->parentFolder !== null) {
            $folderUrl = $cFile->parentFolder->getUrl();
        }

        return $this->render('wallEntryFile', [
            'cFile' => $cFile,
            'fileSize' => $cFile->getSize(),
            'file' => $cFile->baseFile,
            'previewImage' => new PreviewImage(),
            'folderUrl' => $folderUrl,
        ]);
    }

    /**
     * Returns the edit url to edit the content (if supported)
     *
     * @return string url
     */
    public function getEditUrl()
    {
        if (empty(parent::getEditUrl())) {
            return "";
        }

        if ($this->contentObject instanceof File) {
            return $this->contentObject->content->container->createUrl($this->editRoute, ['id' => $this->contentObject->getItemId(), 'fromWall' => true]);
        }

        return "";
    }

    public function getMetadataUrl()
    {
        if (empty(parent::getMetadataUrl())) {
            return "";
        }

        if ($this->contentObject instanceof File) {
            return $this->contentObject->content->container->createUrl($this->metadataRoute, ['id' => $this->contentObject->getItemId(), 'fromWall' => true]);
        }

        return "";
    }

    public function getShowMetadataUrl()
    {
        if (empty(parent::getShowMetadataUrl())) {
            return "";
        }

        if ($this->contentObject instanceof File) {
            return $this->contentObject->content->container->createUrl($this->showMetadataRoute, ['id' => $this->contentObject->getItemId(), 'fromWall' => true]);
        }

        return "";
    }

}
